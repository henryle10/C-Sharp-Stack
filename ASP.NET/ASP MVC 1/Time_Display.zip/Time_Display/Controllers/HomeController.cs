using System;
using Microsoft.AspNetCore.Mvc;

namespace Time_Display.Controllers
{
    public class HomeController : Controller
    {
        [HttpGet("")]
        public IActionResult Index()
        {
            DateTime item = DateTime.Now;
            return View();
        }
    }
}