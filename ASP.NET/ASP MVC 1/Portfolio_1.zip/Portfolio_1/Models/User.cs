namespace Portfolio_1.Models
{
    public class User
    {
        
    }
}