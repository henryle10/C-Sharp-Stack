namespace ViewModel_Fun
{
    public class Integers
    {
        public int[] Ints { get; set; }
    }
}