namespace ViewModel_Fun.Models
{
    public class Stringz
    {
        public string Para { get; set; }
    }
}