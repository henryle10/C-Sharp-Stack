namespace Simple_Login_Registration.Models
{
    public class IndexViewModel
    {
        public User NewUser { get; set; }
        public Login NewLogin { get; set; }
    }
}