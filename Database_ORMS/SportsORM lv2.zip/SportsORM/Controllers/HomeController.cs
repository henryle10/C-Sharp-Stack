﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using SportsORM.Models;
using Microsoft.EntityFrameworkCore;

namespace SportsORM.Controllers
{
    public class HomeController : Controller
    {

        private static Context context;

        public HomeController(Context DBContext)
        {
            context = DBContext;
        }

        [HttpGet("")]
        public IActionResult Index()
        {
            ViewBag.BaseballLeagues = context.Leagues
                .Where(l => l.Sport.Contains("Baseball"));
            return View();
        }

        [HttpGet("level_1")]
        public IActionResult Level1()
        {
            ViewBag.AllWomenLeagues = context.Leagues
                .Where(l => l.Name.Contains("Womens' "));

            ViewBag.AllHockeyLeagues = context.Leagues
                .Where(l => l.Sport.Contains("Hockey"));

            ViewBag.NoFootballLeagues = context.Leagues
                .Where(league => league.Sport != ("Football"));

            ViewBag.Conferences = context.Leagues
                .Where(league => league.Name.Contains("Conference"));

            ViewBag.Atlantic = context.Leagues
                .Where(league => league.Name.Contains("Atlantic"));

            // Contains and == are the same
            ViewBag.Dallas = context.Teams
                .Where(Team => Team.Location.Contains("Dallas"));

            ViewBag.Raptors = context.Teams
                .Where(Team => Team.TeamName == ("Raptors"));

            ViewBag.City = context.Teams
                .Where(Team => Team.Location == ("City"));

            ViewBag.TNames = context.Teams
                .Where(Team => Team.TeamName.StartsWith("T"));

            ViewBag.Alphabetical = context.Teams
                .OrderBy(team => team.TeamName).ToList();

            ViewBag.revAlphabetical = context.Teams
                .OrderByDescending(team => team.TeamName).ToList();

            ViewBag.Cooper = context.Players
                .Where(player => player.LastName == ("Cooper"));

            ViewBag.Joshua = context.Players
                .Where(player => player.FirstName.Contains("Joshua"));

            ViewBag.CooperNoJoshua = context.Players
                .Where(player => player.LastName.Contains("Cooper")
                && player.FirstName != ("Joshua"));

            ViewBag.AlexanderAndWyatt = context.Players
                .Where(player => player.FirstName.Contains("Alexander")
                || player.FirstName.Contains("Wyatt"));

            return View();
        }

        [HttpGet("level_2")]
        public IActionResult Level2()
        {
            ViewBag.TeamsAtlanticSoccer = context.Teams.Include(team => team.CurrLeague).Where(team => team.CurrLeague.Name.Contains("Atlantic") && team.CurrLeague.Sport == ("Soccer")).ToList();

            ViewBag.PenguinCurrPlayers = context.Players.Include(player => player.CurrentTeam).Where(player => player.CurrentTeam.TeamName.Contains("Penguins")).ToList();

            ViewBag.BaseballConference = context.Teams.Include(team => team.CurrLeague).Where(team => team.CurrLeague.Name.Contains("Collegiate") && team.CurrLeague.Sport == ("Baseball")).ToList();

            ViewBag.AmateurFootball = context.Teams.Include(team => team.CurrLeague).Where(team => team.CurrLeague.Name.Contains("American") && team.CurrLeague.Sport == ("Football")).ToList();

            ViewBag.AllFootballLeagues = context.Teams.Include(team => team.CurrLeague).Where(team => team.CurrLeague.Sport.Contains("Football")).ToList();

            ViewBag.SophiaName = context.Players.Include(player => player.AllTeams).Where(player => player.FirstName.Contains("Sophia")).ToList();

            ViewBag.Flores = context.Players.Include(flo => flo.CurrentTeam).Where(flo => flo.LastName == "Flores");

            ViewBag.TigerCats = context.Players.Include(tig => tig.CurrentTeam).Where(tig => tig.CurrentTeam.TeamName == "Tiger-Cats");

            ViewBag.TwelvePlayers = context.Teams.Include(team => team.AllPlayers);
            return View();
        }

        [HttpGet("level_3")]
        public IActionResult Level3()
        {
            return View();
        }

    }
}