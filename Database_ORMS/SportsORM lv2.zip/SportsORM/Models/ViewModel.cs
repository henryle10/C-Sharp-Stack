using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace SportsORM.Models
{
    public class View
    {

    }
}